<?php 

### Zadanie 1: Wyciąganie podciągu i jego długość

// **Polecenie:**
// Napisz skrypt, który wyciągnie z podanego ciągu znaków "Hello World!" słowo "World" i obliczy jego długość.


$txt = "hello world!";
$wynik = substr($txt,6,5);
/* echo $wynik;
echo "<br>";
echo mb_strlen($wynik); */


### Zadanie 2: Podział ciągu na tablicę

// **Polecenie:**
// Napisz skrypt, który podzieli ciąg "apple,banana,cherry" na osobne owoce i wyświetli je jako elementy tablicy.

$txt = "apple,banana,cherry" ;
$wynik = explode(",",$txt);
// print_r($wynik);


### Zadanie 3: Zmiana wielkości liter

// **Polecenie:**
// Napisz skrypt, który zamieni wszystkie litery w ciągu "Hello World!" na wielkie, a następnie na małe.

$txt = "hello world!";
// echo strtoupper($txt);


### Zadanie 4: Usuwanie białych znaków

// **Polecenie:**
// Napisz skrypt, który usunie białe znaki z początku i końca ciągu "  Hello World!  ".



### Zadanie 5: Znalezienie pozycji podciągu

// **Polecenie:**
// Napisz skrypt, który znajdzie pozycję pierwszego wystąpienia słowa "World" w ciągu "Hello World!".

$txt = "hello world!";
 // echo strpos($txt,"world");


### Zadanie 6: Zastępowanie tekstu

// **Polecenie:**
// Napisz skrypt, który zamieni wszystkie wystąpienia słowa "world" na "PHP" w ciągu "Hello world! PHP is a great world!".

// $txt = "Hello world! PHP is a great world!"
// echo str_replace("world","php",$txt);


### Zadanie 7: Powtórzenie ciągu

// **Polecenie:**
// Napisz skrypt, który powtórzy ciąg "PHP" pięć razy.

$txt = "php";
// echo str_repeat($txt,5);


### Zadanie 8: Formatowanie liczby

// **Polecenie:**
// Napisz skrypt, który sformatuje liczbę 1234.5678 do dwóch miejsc po przecinku.

$liczba = 1234.5678;
// var_dump($liczba);
// echo number_format($liczba, 2);


### Zadanie 9: Dekodowanie i kodowanie encji HTML

// **Polecenie:**
// Napisz skrypt, który zakoduje ciąg "This is a test & this is only a test." jako encje HTML, a następnie je zdekoduje.

/* $text = "This is a test & this is only a test.";
$encoded = htmlentities($text);
$decoded = html_entity_decode($text);
var_dump($encoded);
var_dump($decoded); */

### Zadanie 10: Bezpieczne wyświetlanie HTML

// **Polecenie:**
// Napisz skrypt, który zabezpieczy ciąg "<script>alert('Hello');</script>" przed wykonaniem skryptu poprzez zamianę na bezpieczne encje HTML.

 // $txt = "<script>alert('Hello');</script>" ;
// echo htmlspecialchars($txt);

### Zadanie 11: Zmiana pierwszej litery na małą

// **Polecenie:**
// Napisz skrypt, który zmieni pierwszą literę ciągu "Hello World!" na małą.




### Zadanie 12: Zmiana pierwszej litery na wielką
// $txt = "hello World!";
 // echo ucfirst($txt);


// **Polecenie:**
// Napisz skrypt, który zmieni pierwszą literę ciągu "hello world!" na wielką.


### Zadanie 13: Losowe przetasowanie tablicy

// **Polecenie:**
// Napisz skrypt, który przetasuje losowo elementy tablicy ["apple", "banana", "cherry"].


### Zadanie 14: Znaki ucieczki

// **Polecenie:**
// Napisz skrypt, który wyświetli tekst zawierający znaki ucieczki, np. nową linię, tabulator i cudzysłów. Tekst ma brzmieć: "To jest nowa linia\nTo jest tabulator\tTo jest cudzysłów\"".
$txt = "To jest nowa linia\nTo jest tabulator\tTo jest cudzysłów\"";
// echo $txt;
 //echo "<pre>$txt</pre>";
// echo nl2br($txt);

### Zadanie 15: Łączenie funkcji

// **Polecenie:**
// Napisz skrypt, który weźmie ciąg "  Hello WORLD!  ", usunie białe znaki, zamieni wszystkie litery na małe, a następnie pierwszą literę na wielką. -->

$txt = "  Hello WORLD!  ";
echo ucfirst(strtolower(trim($txt)));
?>